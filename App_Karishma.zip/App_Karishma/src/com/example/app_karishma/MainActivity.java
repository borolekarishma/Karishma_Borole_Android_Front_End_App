package com.example.app_karishma;

import com.example.app_karishma.SimpleGestureFilter.SimpleGestureListener;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.MotionEvent;

public class MainActivity extends Activity implements SimpleGestureListener {
	private SimpleGestureFilter detector;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		detector = new SimpleGestureFilter(this, this);
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent me) {
		this.detector.onTouchEvent(me);
		return super.dispatchTouchEvent(me);
	}
	
	@Override
	public void onSwipe(int direction) {
		final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				this);
		
		
		
		String str = "";
		switch (direction) {
		case SimpleGestureFilter.SWIPE_RIGHT:
			str = " Swipe is the most user friendly approach. \n Access to data items using swipe is faster and more enjoyable ";
			break;
		case SimpleGestureFilter.SWIPE_LEFT:
			str = " Android is the most widely used OS for handheld devices. \n Provides Easy access to thousands of applications via the Google Android Android App Market \n ";
			break;
		case SimpleGestureFilter.SWIPE_DOWN:
			str = " Its a great opportunity to work with Zappos as it is recognized as one of the 100 best companies to work for.\n I am interested in working for a front end development position at Zappos.";
			break;
		case SimpleGestureFilter.SWIPE_UP:
			str = " Name: Karishma Borole \n University: University of North Carolina at Charlotte\n Degree: M.S in Computer Science\n ";
			break;
		}

		
		
		alertDialogBuilder.setIcon(R.drawable.ic_launcher);
		alertDialogBuilder.setMessage(str);
		alertDialogBuilder.show();
		
		
	}

	@Override
	public void onDoubleTap() {
		
		
	}
}